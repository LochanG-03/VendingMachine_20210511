﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine_20210511
{

    class Program
    {
        static void Main(string[] args)
        {
            bool purchaseProduct = true;

            do
            {
                bool success = PurchaseProduct();
                if (!success)
                {
                    Console.WriteLine("Do you want to continue? (Y/N)");
                    string input = Console.ReadLine();
                    purchaseProduct = (!String.IsNullOrEmpty(input) && input.ToLower() == "y");
                }

                if (success)
                    purchaseProduct = false;
            }
            while (purchaseProduct);

            Console.ReadLine();
        }

        public static bool PurchaseProduct()
        {
            try
            {
                Product selectedProduct = Product.SelectProduct();
                if (selectedProduct == null)
                    return false;

                double pricePayable = selectedProduct.ProductPrice, amountPaid = 0.0;

                do
                {
                    ICoin coin = null;
                    bool isCoinValid = false;
                    if (amountPaid != pricePayable)
                    {
                        Console.WriteLine("\nInsert Coin:");
                        Console.WriteLine("Valid Coins: Nickel ($0.05) = 1, Dime ($0.10) = 2, Quarter ($0.25) = 3");
                        Console.WriteLine("Enter Coin Type: (1/2/3)");

                        string input = Console.ReadLine();
                        isCoinValid = CoinFactory.ValidateCoin(input, out coin);
                    }

                    if (!isCoinValid || coin == null)
                    {
                        Console.WriteLine("Do you want to continue? (Y/N)");
                        string userChoice = Console.ReadLine();
                        if (!String.IsNullOrEmpty(userChoice) && userChoice.ToLower() == "y")
                        {
                            //continue with payment
                            continue;
                        }
                        else
                        {
                            //user doesn't want to continue
                            return true;
                        }
                    }

                    double currCoinValue = coin.GetCoinValue();
                    if (amountPaid + currCoinValue > pricePayable)
                    {
                        //Console.WriteLine("Invalid coin inserted. Pending amount: ${0:N}", pricePayable - amountPaid);
                        double returnedAmount = Math.Round(pricePayable - (amountPaid + currCoinValue), 4, MidpointRounding.AwayFromZero);
                        Console.WriteLine("Price Payable: ${0:N}\nAmount Paid: ${1:N}\nReturned Amount: ${2:N}",
                                pricePayable, pricePayable, returnedAmount * -1);

                        amountPaid = pricePayable;
                    }
                    else
                    {
                        amountPaid += currCoinValue;
                        amountPaid = Math.Round(amountPaid, 2, MidpointRounding.AwayFromZero);

                        if (amountPaid != pricePayable)
                            Console.WriteLine("Price Payable: ${0:N}\nAmount Paid: ${1:N}\nPending Amount: ${2:N}",
                                pricePayable, amountPaid, pricePayable - amountPaid);
                    }

                }
                while (amountPaid != pricePayable);

                if (amountPaid == pricePayable)
                {
                    Console.WriteLine("\nAmount is fully paid. \nThank you!");
                    return true;
                }

                //still here
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Unexpected error occurred while purchasing the product, error {0}", ex.Message); ;
                return false;
            }
        }

    }
}
