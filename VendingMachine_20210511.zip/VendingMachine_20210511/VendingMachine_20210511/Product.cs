﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine_20210511
{
    public class Product
    {
        public int ProductID { get; set; }

        public string ProductName { get; set; }

        public double ProductPrice { get; set; }

        public override bool Equals(object obj)
        {
            Product compare = obj as Product;
            if (compare == null)
                return false;

            return (this.ProductID == compare.ProductID
                && this.ProductName.Equals(compare.ProductName)
                && this.ProductPrice.Equals(compare.ProductPrice));
        }

        public override int GetHashCode()
        {
            return 0;
        }

        public static List<Product> GetAllProducts()
        {
            List<Product> products = new List<Product>();
            products.Add(new Product()
            {
                ProductID = 1,
                ProductName = "Cola",
                ProductPrice = 1.0
            });

            products.Add(new Product()
            {
                ProductID = 2,
                ProductName = "Chips",
                ProductPrice = 0.50
            });

            products.Add(new Product()
            {
                ProductID = 3,
                ProductName = "Candy",
                ProductPrice = 0.65
            });

            return products;
        }

        public static Product GetProductById(string input)
        {
            List<Product> products = Product.GetAllProducts();
            if (products == null || products.Count == 0)
                return null;

            int productID = -1;
            if (String.IsNullOrEmpty(input) || !Int32.TryParse(input, out productID))
                productID = -1;

            return products.Find(x => x.ProductID == productID);
        }

        public static Product SelectProduct()
        {
            List<Product> products = Product.GetAllProducts();
            if (products == null || products.Count == 0)
            {
                Console.WriteLine("No products to show");
                return null;
            }

            Console.WriteLine("\nProducts available: ");
            foreach (Product product in products)
            {
                Console.WriteLine("{0}\t{1}\t${2:N}", product.ProductID, product.ProductName, product.ProductPrice);
            }

            Console.WriteLine("\nEnter Product ID: ");

            string input = Console.ReadLine();
            return SelectProduct(input);
        }

        public static Product SelectProduct(string input)
        {
            Product selectedProduct = Product.GetProductById(input);
            if (selectedProduct == null)
            {
                Console.WriteLine("Invalid product. Please select valid product.");
                return null;
            }

            Console.WriteLine("Selected Product: {0}, Price Payable: ${1:N}",
                selectedProduct.ProductName, selectedProduct.ProductPrice);

            return selectedProduct;
        }

    }
}
