﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using VendingMachine_20210511;

namespace VendingMachine_Test
{
    [TestClass]
    public class TestVendingMachine
    {
        [TestMethod]
        public void TestValidateCoin_Valid()
        {
            //arrange
            bool expected = true;
            string input = "2";

            //act
            ICoin coin = null;
            bool actual = CoinFactory.ValidateCoin(input, out coin);

            //assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestValidateCoin_Invalid()
        {
            //arrange
            bool expected = false;
            string input = "4";

            //act
            ICoin coin = null;
            bool actual = CoinFactory.ValidateCoin(input, out coin);

            //assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestSelectProduct_Valid()
        {
            //arrange
            string input = "1";
            Product expected = new Product()
            {
                ProductID = 1,
                ProductName = "Cola",
                ProductPrice = 1.0
            };

            //act
            Product actual = Product.SelectProduct(input);

            //assert
            Assert.AreEqual<Product>(expected, actual);
        }

        [TestMethod]
        public void TestSelectProduct_Invalid()
        {
            //arrange
            string input = "100";
            Product expected = null;

            //act
            Product actual = Product.SelectProduct(input);

            //assert
            Assert.AreEqual<Product>(expected, actual);
        }
    }
}
